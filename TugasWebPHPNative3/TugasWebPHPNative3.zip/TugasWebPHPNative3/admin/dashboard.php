<?php

$model = new Produk();
$data_produk = $model->dataProduk();

?>

<head>
    <title>Dashboard - WasiAdmin</title>
</head>
<main>
    <div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    <div class="row">
        <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body">Primary Card</div>
            <div
            class="card-footer d-flex align-items-center justify-content-between"
            >
            <a class="small text-white stretched-link" href="#"
                >View Details</a
            >
            <div class="small text-white">
                <i class="fas fa-angle-right"></i>
            </div>
            </div>
        </div>
        </div>
        <div class="col-xl-3 col-md-6">
        <div class="card bg-warning text-white mb-4">
            <div class="card-body">Warning Card</div>
            <div
            class="card-footer d-flex align-items-center justify-content-between"
            >
            <a class="small text-white stretched-link" href="#"
                >View Details</a
            >
            <div class="small text-white">
                <i class="fas fa-angle-right"></i>
            </div>
            </div>
        </div>
        </div>
        <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body">Success Card</div>
            <div
            class="card-footer d-flex align-items-center justify-content-between"
            >
            <a class="small text-white stretched-link" href="#"
                >View Details</a
            >
            <div class="small text-white">
                <i class="fas fa-angle-right"></i>
            </div>
            </div>
        </div>
        </div>
        <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body">Danger Card</div>
            <div
            class="card-footer d-flex align-items-center justify-content-between"
            >
            <a class="small text-white stretched-link" href="#"
                >View Details</a
            >
            <div class="small text-white">
                <i class="fas fa-angle-right"></i>
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-6">
        <div class="card mb-4">
            <div class="card-header">
            <i class="fas fa-chart-area me-1"></i>
            Area Chart Example
            </div>
            <div class="card-body">
            <canvas id="myAreaChart" width="100%" height="40"></canvas>
            </div>
        </div>
        </div>
        <div class="col-xl-6">
        <div class="card mb-4">
            <div class="card-header">
            <i class="fas fa-chart-bar me-1"></i>
            Bar Chart Example
            </div>
            <div class="card-body">
            <canvas id="myBarChart" width="100%" height="40"></canvas>
            </div>
        </div>
        </div>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col">
                    <div type="button" class="">
                        <h4>Data Product</h4>
                    </div>
                </div>
                <div class="col">
                    <a href="?url=product-form">
                    <button type="button" class="btn btn-primary" data-mdb-toggle="modal" data-mdb-target="#staticBackdrop1">
                        Add New Product
                    </button>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
        <table id="datatablesSimple">
            <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Stok</th>
                <th>Minimal Stok</th>
                <th>Jenis Produk </th>
                <th>Action</th>
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>Stok</th>
                <th>Minimal Stok</th>
                <th>Jenis Produk </th>
                <th>Action</th>
            </tr>
            </tfoot>
            <tbody>
                <?php
                $no = 1;
                foreach($data_produk as $row){

                ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $row['kode']?></td>
                    <td><?= $row['nama']?></td>
                    <td><?= $row['harga_beli']?></td>
                    <td><?= $row['harga_jual']?></td>
                    <td><?= $row['stok']?></td>
                    <td><?= $row['min_stok']?></td>
                    <td><?= $row['jenis_produk_id']?></td>
                    <td>
                        <form action="produk_controller.php" method="POST">
                            <a class="btn btn-info btn-sm" href="?url=product-detail&id=<?= $row ['id'] ?>">Detail</a>
                            <a class="btn btn-warning btn-sm">Ubah</a>
                            <a class="btn btn-danger btn-sm">Hapus</a>

                            <input type="hidden" name="idx" value="<?= $row['id']?>">
                        </form>
                    </td>
                </tr>
                <?php
                $no++; 
            } 
                ?>
            </tbody>
        </table>
        </div>
    </div>
    </div>
</main>